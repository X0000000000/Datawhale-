import os

# 打开文本文件并读取内容
with open('填充.txt', 'r', encoding='utf-8') as file:
    lines = file.readlines()

# 在每一行后面加入逗号
json_lines = [line.strip() + ',\n' for line in lines]

# 将修改后的内容写入文件（这里覆盖原有文件）
with open('填充.txt', 'w', encoding='utf-8') as file:
    file.writelines(json_lines)  # 将修改后的内容写入文件

# 打印输出结果
print('修改后的文件内容：')
with open('填充.txt', 'r', encoding='utf-8') as file:
    content = file.read()
    print(content)
