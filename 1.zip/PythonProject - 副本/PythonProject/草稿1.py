import os

# 读取文件并处理
with open('训练集.txt', 'r', encoding='utf-8') as file:
    lines = file.readlines()
    # 去除序号，只保留每行的第二部分（假设用制表符分隔）
    lines = [line.strip().split('\t')[1] for line in lines if '\t' in line]  # 添加检查以确保存在制表符
    # 去除空行（由于strip()已经去除首尾空白，这里主要检查split后的结果）
    lines = [line for line in lines if line]
    # 去除重复行
    lines = list(set(lines))

    # 输出到文件，确保每个字符串后都有换行符
    with open('训练集_output.txt', 'w', encoding='utf-8') as new_file:
        for line in lines:
            new_file.write(line + '\n')  # 使用write()方法并手动添加换行符

print('训练集_output.txt文件已生成！')